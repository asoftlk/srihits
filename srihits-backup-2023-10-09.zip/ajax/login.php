<?php
session_start();
$_SESSION['userid'] = $_POST['id'];
?>