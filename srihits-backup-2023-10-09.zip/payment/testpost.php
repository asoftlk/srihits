<?php
print_r(get_defined_vars());
?>