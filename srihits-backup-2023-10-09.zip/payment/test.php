<?php
echo '<form method="post" action="testpost.php">
<input type="text" name="name" >
<input type="submit" value="sumbit">
</form>';
?>
