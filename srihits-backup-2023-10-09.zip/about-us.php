<?php include "header.php"; ?>
<div class="container text-light mt-4">
    <p>
  <h4>About us</h4>
</p>
<p>SriHits is the platform where all the films and many other artistic creations done by Dr. Somaratne Dissanayake are available. Apart from the films by the most popular and successful film director of the country many more carefully selected quality films by other creators also available here.</p>
<p>
  <br>
</p>
<p>
  <b>Films</b>
</p>
<p>Saroja</p>
<p>Punchi Suranganavi (Little Angel)</p>
<p>Suriya Arana</p>
<p>Samanala Thatu (Butterfly Wings)</p>
<p>Sankara</p>
<p>Siri Raja Siri (King Siri)</p>
<p>Bindu</p>
<p>Siri Perakum</p>
<p>Kusa paba</p>
<p>Sarigama</p>
<p>Tsunami</p>
<p>Jangi Hora (Underpant Thief)</p>
<p>
  <br>
</p>
<p>
  <b>Tele-dramas</b>
</p>
<p>Punchi Petaw</p>
<p>Awasanda</p>
<p>Suwada Kekulu</p>
<p>Iti Pahan 1</p>
<p>Iti Pahan 2</p>
<p>Short films, documentaries, Tv interviews, Stage dramas, Music songs are also available.</p>
</div>
<?php include "footer.php"; ?>