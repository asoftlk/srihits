<?php 

//Define your Server host name here.
 $HostName = "localhost";
 
 //Define your MySQL Database Name here.
 $DatabaseName = "srihits_dB";
 
 //Define your Database User Name here.
 $HostUser = "srihits1234";
 
 //Define your Database Password here.
 $HostPass = "mGf4#lZ9rJMo"; 

?>